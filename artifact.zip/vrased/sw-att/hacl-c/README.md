# HACL-C
HACL* verified C code (READ-ONLY)

Please read more information at https://github.com/mitls/hacl-star.

Beware of the trusted code base `kermlib.{h,c}`, `gcc-compat.h` and `testlib.{h,c}`

Pull Requests or Issues should be opened in the correct main repository.
https://github.com/mitls/hacl-star (for the verified code)
or
https://github.com/FStarLang/kremlin (for most of the TCB)
