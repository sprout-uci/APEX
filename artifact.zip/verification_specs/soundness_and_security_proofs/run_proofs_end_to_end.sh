sh install.sh
chmod +x *.ltl
sh proof_theorem1.ltl
sh proof_theorem2_1.ltl
sh proof_theorem2_2.ltl
