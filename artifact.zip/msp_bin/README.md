### README

Memory configurations generated from the compilation of SW-Att (smem.mem) and application code (pmem.mem).
